import{h as r}from"./index-C5zp53bg.js";const n=r({name:"VNodeRenderer",props:{nodes:{type:[Array,Object],required:!0}},setup(e){return()=>e.nodes}});export{n as V};
