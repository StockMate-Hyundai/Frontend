/* empty css              */import{c as r}from"./VAvatar-DlzqFVaJ.js";const e=r("v-spacer","div","VSpacer");export{e as V};
